/* CC0 stock models from Poly Haven. See MODEL-CREDITS.md. */
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const layer = document.createElement('div');
  layer.className = 'stock-props'; layer.setAttribute('aria-hidden', 'true');
  document.body.append(layer);
  const specs = [
    ['Camera_01/lens.gltf', -25, 74],
    ['Camera_01/model.gltf', 25, 73],
    ['vintage_video_camera/model.gltf', 30, 75],
    ['filmstrip_projector_8mm/model.gltf', -35, 76],
    ['cassette_player/model.gltf', 20, 48],
    ['portable_cassette_player/model.gltf', -25, 65]
  ];
  const props = specs.map(([file, angle, elevation], i) => {
    const wrap = document.createElement('div'); wrap.className = 'stock-prop prop-' + i;
    const model = document.createElement('model-viewer');
    model.setAttribute('alt',''); model.setAttribute('tabindex','-1');
    model.setAttribute('camera-orbit', `${angle}deg ${elevation}deg 85%`);
    model.setAttribute('interaction-prompt','none');
    model.setAttribute('shadow-intensity','.6'); model.setAttribute('shadow-softness','1');
    model.setAttribute('exposure','1.15'); model.setAttribute('loading','eager');
    model.dataset.src = 'assets/models/' + file;
    model.addEventListener('load', () => wrap.classList.add('ready'));
    model.addEventListener('error', () => wrap.classList.add('failed'));
    wrap.append(model);layer.append(wrap);
    return {wrap, model, angle, elevation};
  });
  function rect(selector) { const r=document.querySelector(selector).getBoundingClientRect();return {left:r.left,right:r.right,top:r.top+scrollY,bottom:r.bottom+scrollY,width:r.width,height:r.height}; }
  function layout() {
    const main=rect('main'), studio=rect('.studio'), work=rect('#work'), projects=rect('#projects'), contact=rect('#contact');
    layer.style.height=document.body.scrollHeight+'px';
    const mobile=innerWidth<760;
    const side=Math.max(60,main.left-22);
    const size=mobile?90:Math.min(235,side*.95);
    const left=mobile?2:Math.max(8,(main.left-size)/2);
    const right=mobile?innerWidth-size-2:main.right+(innerWidth-main.right-size)/2;
    const positions = [
      [main.left+main.width*.14,studio.top+40,size*.65],
      [main.right-size-12,studio.top-5,size*.85],
      [left,mobile?work.top+5:projects.top+15,size],
      [right,mobile?projects.bottom+30:projects.top+projects.height*.56,size],
      [left,mobile?contact.bottom-90:contact.top+180,size*.83],
      [right,contact.bottom-(mobile?90:155),size*.7]
    ];
    props.forEach(({wrap},i)=>{const [x,y,s]=positions[i];Object.assign(wrap.style,{left:x+'px',top:y+'px',width:s+'px',height:s+'px'});});
    update();
  }
  let frame=0;
  function update() {
    frame=0;
    props.forEach(({wrap,model,angle,elevation})=>{
      const r=wrap.getBoundingClientRect();
      if(r.top<innerHeight+240 && r.bottom>-240 && !model.hasAttribute('src')) model.setAttribute('src',model.dataset.src);
      if(r.top<innerHeight*.93) wrap.classList.add('visible');
      if(!reduced.matches && r.top<innerHeight && r.bottom>0) {
        const p=Math.max(-1,Math.min(1,(innerHeight*.5-r.top)/innerHeight));
        model.setAttribute('camera-orbit',`${angle+p*16}deg ${elevation}deg 85%`);
        model.style.transform=`translateY(${p*-12}px)`;
      }
    });
  }
  addEventListener('scroll',()=>{if(!frame)frame=requestAnimationFrame(update);},{passive:true});
  addEventListener('resize',layout);addEventListener('load',layout);
  new ResizeObserver(layout).observe(document.querySelector('main'));
  reduced.addEventListener('change',()=>{props.forEach(({model})=>model.style.transform='');update();});
  const script=document.createElement('script');script.type='module';script.src='vendor/model-viewer.min.js';document.head.append(script);
  layout();
  const start=performance.now();
  const timer=document.querySelector('#rec-time');
  if(!reduced.matches)setInterval(()=>{if(document.hidden)return;const f=Math.floor((performance.now()-start)/40);timer.textContent=[Math.floor(f/90000)%24,Math.floor(f/1500)%60,Math.floor(f/25)%60,f%25].map(n=>String(n).padStart(2,'0')).join(':');},200);
})();


