const grid = document.querySelector('#projects');
const buttons = [...document.querySelectorAll('[data-lang]')];
const cardObserver = new IntersectionObserver(entries => {
  for (const entry of entries) if (entry.isIntersecting) {
    entry.target.style.setProperty('--reveal', '1');
    cardObserver.unobserve(entry.target);
  }
}, {rootMargin: '0px 0px -35px 0px', threshold: 0});
let language = 'RU';
function showWork(lang) {
  language = lang;
  cardObserver.disconnect();
  grid.querySelectorAll('video').forEach(video => { video.pause(); video.removeAttribute('src'); video.load(); });
  grid.replaceChildren();
  window.PORTFOLIO[lang].forEach((project, index) => {
    const article = document.createElement('article'); article.className = 'project line-reveal'; article.style.setProperty('--reveal', '0');
    const wrap = document.createElement('div'); wrap.className = 'video-wrap';
    const video = document.createElement('video'); video.controls = true; video.playsInline = true; video.preload = 'metadata';
    video.src = project.src + '#t=0.1'; video.setAttribute('aria-label', project.title + ' — ' + lang);
    video.addEventListener('play', () => grid.querySelectorAll('video').forEach(other => { if (other !== video) other.pause(); }));
    video.addEventListener('error', () => {
      const fallback = document.createElement('p'); fallback.className = 'video-fallback';
      fallback.append('Не удалось воспроизвести видео. ');
      const link = document.createElement('a'); link.href = project.src; link.textContent = 'Открыть файл'; fallback.append(link);
      wrap.replaceChildren(fallback);
    }, {once:true});
    wrap.append(video);
    const meta = document.createElement('div'); meta.className = 'project-meta';
    const title = document.createElement('h3'); title.textContent = project.title;
    const tag = document.createElement('span'); tag.textContent = lang + ' / 0' + (index + 1);
    meta.append(title, tag); article.append(wrap, meta); grid.append(article);
    cardObserver.observe(article);
  });
  buttons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.lang === lang)));
  document.querySelector('#work-status').textContent = lang === 'RU' ? 'Показаны две работы на русском языке.' : 'Показаны две работы на английском языке.';
  requestAnimationFrame(drawThread);
}
buttons.forEach(button => button.addEventListener('click', () => { if (language !== button.dataset.lang) showWork(button.dataset.lang); }));



const svg = document.querySelector('.thread');
const guide = document.querySelector('.thread-guide');
const ribbon = document.querySelector('.thread-ribbon');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
ribbon.removeAttribute('mask');
let length=1,samples=[],ticking=false,drawn=0,lastFrame=0,revealRanges=[];
const introStart=performance.now();
const clamp=v=>Math.max(0,Math.min(1,v));
const smooth=v=>{const t=clamp(v);return t*t*(3-2*t);};
function pageRect(target){const r=(typeof target==='string'?document.querySelector(target):target).getBoundingClientRect();return {left:r.left,right:r.right,top:r.top+scrollY,bottom:r.bottom+scrollY,width:r.width,height:r.height};}
const secondaryGuide = document.createElementNS('http://www.w3.org/2000/svg','path');
secondaryGuide.setAttribute('fill','none');secondaryGuide.setAttribute('stroke','none');
const secondaryRibbon = document.createElementNS('http://www.w3.org/2000/svg','path');
secondaryRibbon.setAttribute('class','thread-ribbon');svg.append(secondaryGuide,secondaryRibbon);
// Opaque white copy clipped by the exact animated ribbon geometry.
const workTitle=document.querySelector('.work-heading h2');
const titleWhite=document.createElement('span');
titleWhite.className='title-inversion';titleWhite.setAttribute('aria-hidden','true');
titleWhite.innerHTML=workTitle.innerHTML;workTitle.append(titleWhite);
const titleClip=document.createElementNS(svg.namespaceURI,'clipPath');
titleClip.id='heading-ribbon-clip';titleClip.setAttribute('clipPathUnits','userSpaceOnUse');
const titleClipPaths=[ribbon,secondaryRibbon].map(()=>document.createElementNS(svg.namespaceURI,'path'));
titleClip.append(...titleClipPaths);svg.querySelector('defs').append(titleClip);
let titleOffset={left:0,top:0};
let branchSamples=[],branchLength=0,branchStart=0,branchEnd=1,branchReveal={start:0,end:1};
const revealStrokes = [ribbon, secondaryRibbon].map((path, index) => {
  const mask = document.createElementNS(svg.namespaceURI, 'mask');
  mask.id = 'ribbon-progress-' + index;
  mask.setAttribute('maskUnits', 'userSpaceOnUse');
  const stroke = document.createElementNS(svg.namespaceURI, 'path');
  stroke.setAttribute('style', 'fill:none;stroke:white;stroke-width:60;stroke-linecap:round');
  mask.append(stroke); svg.querySelector('defs').append(mask);
  path.setAttribute('mask', `url(#${mask.id})`);
  return stroke;
});
let headingSamples = [];
function curvePath(knots,path){
  let d=`M ${knots[0].x} ${knots[0].y}`;const distances=[0];
  for(let i=1;i<knots.length;i++){
    const a=knots[i-1],b=knots[i];
    d+=` C ${a.x+a.tx} ${a.y+a.ty}, ${b.x-b.tx} ${b.y-b.ty}, ${b.x} ${b.y}`;
    path.setAttribute('d',d);distances.push(path.getTotalLength());
  }
  return distances;
}
function sampleCurve(path,total,maxWidth){
  const list=[],count=Math.ceil(total/3);
  for(let i=0;i<=count;i++){
    const s=total*i/count,p=path.getPointAtLength(s),a=path.getPointAtLength(Math.max(0,s-1)),b=path.getPointAtLength(Math.min(total,s+1));
    const dx=b.x-a.x,dy=b.y-a.y,m=Math.hypot(dx,dy)||1;
    list.push({s,x:p.x,y:p.y,nx:-dy/m,ny:dx/m,w:maxWidth*(.86+.14*Math.sin(s/total*Math.PI*3)**2)*smooth(s/85)});
  }
  return list;
}
function drawThread(){
  const brand=document.querySelector('.brand'),main=pageRect('main'),bio=pageRect('.bio-lead'),work=pageRect('#work'),cta=pageRect('.contact-button');
  const cards=[...grid.querySelectorAll('.project')],boxes=cards.map(el=>pageRect(el.querySelector('.video-wrap')));
  const [first,second]=boxes,width=document.documentElement.clientWidth,mobile=width<=700;
  const height=pageRect('footer').bottom;
  titleOffset=pageRect(workTitle);
  titleClipPaths.forEach(path=>path.setAttribute('transform',`translate(${-titleOffset.left} ${-titleOffset.top})`));
  svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.style.height=height+'px';
  const overlap=Math.min(9,brand.offsetWidth*.008);
  const x=main.left+brand.offsetLeft+brand.offsetWidth*.0015+overlap,y=main.top+brand.offsetTop+brand.offsetHeight*.909-overlap*.83;
  const outerLeft=width*.045,outerRight=width*.955,bioY=bio.bottom+20;
  const split={x:width*.55,y:first.top-85,tx:-width*.12,ty:30};
  const lowerLeft=first.left+first.width*.42,lowerRight=second.left+second.width*.61;
  const join={x:(lowerLeft+lowerRight)/2,y:work.bottom+65,tx:Math.max(35,(lowerRight-lowerLeft)*.22),ty:0};
  const endX=cta.right+14,endY=cta.top+cta.height/2;
  const knots=[
    {x,y,tx:-Math.min(145,Math.max(24,(x-outerLeft)*.8)),ty:Math.min(145,Math.max(24,(x-outerLeft)*.8))*.83},
    {x:Math.max(20,width*.045),y:bioY-62,tx:0,ty:Math.min(82,Math.max(38,(bioY-y)*.27))},
    {x:bio.left,y:bioY,tx:Math.min(230,main.width*.24),ty:-8},
    {x:bio.right-60,y:bioY,tx:90,ty:6},
    {x:outerRight,y:bioY+90,tx:0,ty:100},
    split,
    {x:first.left+first.width*.48,y:first.top+first.height*.2,tx:mobile?-20:-35,ty:100},
    {x:first.left+first.width*.42,y:first.bottom-25,tx:mobile?-20:-40,ty:100},
    {x:lowerLeft,y:work.bottom+43,tx:25,ty:35},
    join,
    {x:outerRight-18,y:pageRect('.contact h2').top+80,tx:0,ty:105},
    {x:endX,y:endY,tx:-65,ty:0}
  ];
  // The sketch's second loop passes behind the second film and reunites below.
  const branch=[
    {x:split.x,y:split.y,tx:width*.12,ty:35},
    {x:second.left+second.width*.60,y:second.top+second.height*.22,tx:35,ty:110},
    {x:second.left+second.width*.61,y:second.bottom-20,tx:40,ty:100},
    {x:lowerRight,y:work.bottom+43,tx:-25,ty:35},
    {x:join.x,y:join.y,tx:-join.tx,ty:0}
  ];
  const distances=curvePath(knots,guide),oldLength=length;
  length=distances.at(-1);drawn=Math.min(length,drawn*length/oldLength);
  branchStart=distances[5];branchEnd=distances[9];
  const branchDistances=curvePath(branch,secondaryGuide);branchLength=branchDistances.at(-1);
  const maxWidth=Math.max(8,Math.min(22,brand.offsetWidth*.021));
  samples=sampleCurve(guide,length,maxWidth);branchSamples=sampleCurve(secondaryGuide,branchLength,maxWidth);
  branchReveal={start:branchDistances[1]-75,end:branchDistances[2]};
  revealRanges=[{el:cards[0],start:distances[6]-75,end:distances[7]}, {el:cards[1],start:0,end:1}];
  let frontier=y,previousS=0;
  for(const p of samples){frontier=Math.max(frontier+(p.s-previousS)*.16,p.y);p.revealY=frontier;previousS=p.s;}
  const scale=(endY+45-y)/Math.max(1,frontier-y);samples.forEach(p=>p.revealY=y+(p.revealY-y)*scale);
  [guide,secondaryGuide].forEach((path,i)=>{
    const total=i?branchLength:length;
    revealStrokes[i].setAttribute('d',path.getAttribute('d'));
    revealStrokes[i].setAttribute('stroke-dasharray',`${total} ${total}`);
    const mask=revealStrokes[i].parentNode;
    mask.setAttribute('x','0');mask.setAttribute('y','0');
    mask.setAttribute('width',width);mask.setAttribute('height',height);
  });
  fillRibbon(ribbon,samples,guide,length);
  fillRibbon(secondaryRibbon,branchSamples,secondaryGuide,branchLength);
  headingSamples=[samples,branchSamples].map(points=>points.filter(p=>p.y>titleOffset.top-40&&p.y<titleOffset.bottom+40));
  scheduleThread();
}
function fillRibbon(path,points,geometry,amount){
  if(amount<.1){path.setAttribute('d','');return;}
  const a=[],b=[];
  for(const p of points){if(p.s>amount)break;const w=p.w*.5*smooth((amount-p.s)/72);a.push(`${(p.x+p.nx*w).toFixed(2)},${(p.y+p.ny*w).toFixed(2)}`);b.push(`${(p.x-p.nx*w).toFixed(2)},${(p.y-p.ny*w).toFixed(2)}`);}
  const tip=geometry.getPointAtLength(amount);
  path.setAttribute('d','M '+a.join(' L ')+` L ${tip.x},${tip.y} L `+b.reverse().join(' L ')+' Z');
}
function renderRibbon(){
  const branchDrawn=branchLength*clamp((drawn-branchStart)/(branchEnd-branchStart));
  revealStrokes[0].setAttribute('stroke-dashoffset',length-drawn);
  revealStrokes[1].setAttribute('stroke-dashoffset',branchLength-branchDrawn);
  // Only the short section crossing the heading needs a changing text clip.
  [drawn,branchDrawn].forEach((amount,i)=>{
    const points=headingSamples[i].filter(p=>p.s<=amount);
    if(points.length<2){titleClipPaths[i].setAttribute('d','');return;}
    const edge=sign=>points.map(p=>`${p.x+sign*p.nx*p.w*.5},${p.y+sign*p.ny*p.w*.5}`);
    titleClipPaths[i].setAttribute('d','M '+edge(1).join(' L ')+' L '+edge(-1).reverse().join(' L ')+' Z');
  });
}
function targetLength(){
  const maxScroll=Math.max(0,document.documentElement.scrollHeight-innerHeight);
  const approach=clamp((scrollY-Math.max(0,maxScroll-280))/280);
  const horizon=scrollY+innerHeight*(.74+.26*approach);
  if(horizon<=samples[0].revealY)return 0;
  if(horizon>=samples.at(-1).revealY)return length;
  let lo=0,hi=samples.length-1;
  while(hi-lo>1){const mid=(lo+hi)>>1;if(samples[mid].revealY<horizon)lo=mid;else hi=mid;}
  const a=samples[lo],b=samples[hi];return a.s+(b.s-a.s)*(horizon-a.revealY)/(b.revealY-a.revealY);
}
function scheduleThread(){if(!ticking){ticking=true;lastFrame=performance.now();requestAnimationFrame(updateThread);}}
function updateThread(now){
  const dt=Math.min(40,Math.max(1,now-lastFrame));lastFrame=now;
  const entrance=clamp((now-introStart-550)/1400);
  const target=reduced.matches?length:targetLength()*(1-Math.pow(1-entrance,3));
  if(reduced.matches)drawn=length;
  else drawn+=(target-drawn)*(1-Math.exp(-dt/65));
  renderRibbon();
  if(!reduced.matches&&(Math.abs(target-drawn)>.15||entrance<1))requestAnimationFrame(updateThread);else ticking=false;
}
addEventListener('scroll',scheduleThread,{passive:true});
addEventListener('resize',drawThread);
addEventListener('load',drawThread);
reduced.addEventListener('change',scheduleThread);
showWork('RU');








const contactDialog=document.querySelector('#contact-dialog');
const contactTrigger=document.querySelector('.contact-button');
contactTrigger.addEventListener('click',()=>contactDialog.showModal());
contactDialog.querySelector('.dialog-close').addEventListener('click',()=>contactDialog.close());
contactDialog.addEventListener('click',event=>{
  if(event.target!==contactDialog)return;
  const r=contactDialog.getBoundingClientRect();
  if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)contactDialog.close();
});
contactDialog.addEventListener('close',()=>contactTrigger.focus({preventScroll:true}));
