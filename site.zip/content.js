window.PORTFOLIO = {
  RU: [
    { title: 'Работа 01', src: 'assets/ru-01.mp4', original: '45$.mp4' },
    { title: 'Работа 02', src: 'assets/ru-02.mp4', original: '35$.mp4' }
  ],
  EN: [
    { title: 'Work 01', src: 'assets/en-01.mp4', original: '55$.mp4' },
    { title: 'Work 02', src: 'assets/en-02.mp4', original: '40$.mp4' }
  ]
};
